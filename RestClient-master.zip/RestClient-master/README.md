# RestClient
Consuming a rest client from Swift
